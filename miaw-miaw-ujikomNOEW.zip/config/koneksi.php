<?php 
	//well done with this hehehehe
	$sql = mysql_connect("192.168.0.199", "dhibrizi03", "kometotelo");
	mysql_select_db("db_dafa");
?>