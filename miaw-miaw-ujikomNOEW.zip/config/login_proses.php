<?php
    include 'koneksi.php';
    session_start();

    $username = $_POST['usr'];
    $pass     = $_POST['pass'];
    $sql = mysql_query("select * from user where username='$username' and password='$pass'");
    $hit = mysql_fetch_array($sql);
    $row = mysql_num_rows($sql);

    $_SESSION['username'] = $username;

    if(isset($_SESSION['username'])){
        echo "Halo ".$username;
    }
    if($row['id_level'] == 1){
        echo "Hello Admin";
    }
?>