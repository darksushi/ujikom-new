<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Food Cult - Login</title>
</head>
<body>
    <form action="../config/login_proses.php" method="post">
        <table>
            <tr>
                <td>Username</td>
                <td>:</td>
                <td><input type="text" name="usr" id="usr"></td>
            </tr>
            <tr>
                <td>Password</td>
                <td>:</td>
                <td><input type="password" name="pass" id="pass"></td>
            </tr>
            <tr>
                <td><button type="submit">Masuklah</button></td>
            </tr>
        </table>
    </form>
</body>
</html>