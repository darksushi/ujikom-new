<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="assets/css/master.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
    <title>Food Cult</title>
</head>
<body>
    <header>
        <div class="wrapper">
            <div class="logo-box"> FoodCult </div>
            <ul>
                <li><a href=""><i class="fas fa-shopping-basket"></i></a></li>
                <li><a href="">Start</a></li>
                <li><a href="">Contact</a></li>
                <li><a href="">Menu</a></li>
            </ul>
            <a href=""><button class="signin">Sign In</button></a>
        </div>
    </header>
    <section class="sec-jumbotron">
        <div class="sec-shadow-1"></div>
    </section>
    <section class="sec-2">
        <h1 class="h1-heading">HIGHLIGHT MENU</h1>
        <div class="flex-con-sec2">
            <div class="grid-food">
                <div class="grid-food-img"></div>
            </div>
            <div class="grid-food">
                <div class="grid-food-img"></div>
            </div>
            <div class="grid-food">
                <div class="grid-food-img"></div>
            </div>
        </div>
    </section>
</body>
</html>