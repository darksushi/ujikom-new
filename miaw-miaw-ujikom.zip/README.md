# ujikom-new
ujikom ahay kebangetan
