<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="assets/css/master.css">
    <title>Food Cult</title>
</head>
<body>
    <header>
        <div class="wrapper">
            <div class="logo-box"> FoodCult </div>
            <ul>
                <li><a href=""><button class="signin">Sign Up</button></a></li>
                <li><a href="">Tier</a></li>
                <li><a href="">Amoe</a></li>
            </ul>
        </div>
    </header>
    <section class="sec-jumbotron">
        <div class="sec-shadow-1"></div>
    </section>
    <section class="sec-2">
        <h1 class="h1-heading">Menu Terfavorit Yang Ada Disini</h1>
        <div class="wrap-sec2">
        </div>
    </section>
</body>
</html>